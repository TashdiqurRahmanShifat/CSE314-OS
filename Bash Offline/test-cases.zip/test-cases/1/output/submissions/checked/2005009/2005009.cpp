#include <iostream>
using namespace std;
int main() {
    cout << "Expected line 1" << endl;
    cout << "Wrong line 2" << endl;
    cout << "Wrong line 3" << endl;
    cout << "Expected line 4" << endl;
    cout << "Expected line 5" << endl;
    cout << "Wrong line 6" << endl;
    cout << "Wrong line 7" << endl;
    cout << "Expected line 8" << endl;
    cout << "Expected line 9" << endl;
    cout << "Expected line 10" << endl;
    cout << "Expected line 11" << endl;
    cout << "Expected line 12" << endl;
    cout << "Wrong line 13" << endl;
    cout << "Expected line 14" << endl;
    cout << "Wrong line 15" << endl;
    cout << "Expected line 16" << endl;
    cout << "Expected line 17" << endl;
    cout << "Expected line 18" << endl;
    cout << "Expected line 19" << endl;
    cout << "Expected line 20" << endl;
    return 0;
}
